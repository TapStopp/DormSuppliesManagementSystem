CREATE TABLE intExample (age int, birthYear int, idNum bigint);
INSERT INTO intExample (age, birthYear, idNum)
VALUES (21, 2004, 123456789);
SELECT * FROM intExample;